============
Installation
============

We recommend using `pip`_ to install the SDK:

    pip install facebook-sdk

.. _pip: http://www.pip-installer.org/
