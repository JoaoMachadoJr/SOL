.. Facebook SDK for Python documentation master file, created by
   sphinx-quickstart on Mon Oct 15 01:01:28 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Facebook SDK for Python's documentation!
===================================================

Contents:

.. toctree::
   :maxdepth: 2

   intro
   install


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

